﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EvolentAssignment.Common
{
    public class DataValidation
    {
       public const string NumbersOnly = @"^[0-9]*$";
       public const string Alphanumeric = @"^[a-zA-Z0-9_]*$";
       public const string Email = @"^(([""\/][_A-Za-z0-9-\\.\\+]+(\\.[_A-Za-z0-9-][""\/])*[""\/])|([_A-Za-z0-9-\\.\\+]+(\\.[_A-Za-z0-9-]+)*))@(?:([^-][A-Za-z0-9-.]+([A-Za-z0-9]+)(.ac|.academy|.accountants|.ag|.agency|.airforce|.am|.as|.army|.asia|.at|.az|.bargains|.be|.best|.bike|.biz|.blue|.bz|.build|.builders|.business|.buzz|.boutique|.cab|.camera|.careers|.cc|.cd|.ch|.cheap|.click|.club|.cn|.clothing|.cool|.co.at|.co.gg|.co.il|.co.in|.co.je|.co.nz|.co.tm|.co.tt|.co.uk|.co.vi|.co.za|.codes|.coffee|.company|.computer|.construction|.contractors|.com|.com.ag|.com.az|.com.cn|.com.es|.com.fr|.com.gr|.com.hr|.com.ph|.com.ro|.com.tw|.com.vn|.cooking|.country|.cruises|.de|.dental|.diamonds|.diet|.digital|.directory|.dk|.domains|.engineering|.enterprises|.email|.equipment|.es|.estate|.eu|.exchange|.farm|.fi|.fishing|.flights|.florist|.fo|.fr|.gallery|.gent|.gg|.gift|.graphics|.gs|.guitars|.guru|.healthcare|.help|.hk|.holdings|.holiday|.hosting|.house|.info|.international|.in|.it|.immo|.io|.je|.jp|.kg|.kitchen|.kiwi|.koeln|.land|.li|.lighting|.limo|.link|.london|.management|.marketing|.me|.menu|.mobi|.ms|.name|.navy|.net|.net.ag|.net.cn|.net.nz|.net.pl|.net.ru|.network|.ninja|.nl|.no|.nu|.ooo|.org|.org.uk|.ph|.photo|.photos|.photography|.pink|.pizza|.pl|.plumbing|.property|.pt|.recipes|.red|.rentals|.restaurant|.ro|.rodeo|.ru|.se|.sh|.shoes|.singles|.solar|.support|.systems|.tc|.tattoo|.tel|.technology|.tips|.tm|.to|.today|.top|.tt|.training|.tv|.us|.vacations|.ventures|.vc|.villas|.vg|.vodka|.voyage|.vu|.ws|.watch|.wiki|.zone))|([\[][0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}[\]])|([0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}))$";
       public const string CharactersWithSpace = @"^[a-zA-Z ]+$";
       
    }
}